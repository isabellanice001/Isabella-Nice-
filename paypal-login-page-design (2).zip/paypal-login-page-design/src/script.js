const paypalLoginBtn = document.getElementById('paypal-login-btn');

paypalLoginBtn.addEventListener('click', () => {

  window.location.href = '(https://www.paypal.com/Login)';

});

```